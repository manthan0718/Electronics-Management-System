﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Electronic_Management_System
{
    public partial class Employee : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                ViewState.Add("foundflag", false);
                GetMaxID();
                ShowGrid();
            }

        }

        protected void ShowGrid()
        {
            DAL d = new DAL();
            DataTable dt = d.GetTable("Select * from employee");
            grddata.DataSource = dt;
            grddata.DataBind();
        }

        public void GetMaxID()
        {
            try
            {
                DAL d = new DAL();
                d.isProcCall = true;
                d.ClearParameters();
                d.AddParameters("action", "getmax");
                d.AddParameters("empid", "0");
                object MaxId = d.GetID("pr_employee");
                d.isProcCall = false;
                txtempid.Text = MaxId + "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        protected void txtsave_Click(object sender, EventArgs e)
        {
            DAL d = new DAL();
            d.ClearParameters();
            d.AddParameters("empid",Common.cint(txtempid.Text).ToString());
            d.AddParameters("empname", txtempname.Text);
            d.AddParameters("gender", gender.Text);
            d.AddParameters("contact", txtcontact.Text);
            d.AddParameters("email", txtemail.Text);
            d.AddParameters("adhar", txtadhar.Text);
            d.AddParameters("address", txtaddress.Text);
            d.AddParameters("workshift", txtwork.Text);
            d.AddParameters("joining_date", txtjoining.Text);
            d.AddParameters("job_role", jobrole.Text);
            d.AddParameters("qualification", txtqua.Text);
            d.isProcCall = true;

            if ((bool)ViewState["foundflag"])
            {
                d.AddParameters("action", "update");
            }
            else
            {
                d.AddParameters("action", "insert");
            }

            int res = d.ExecuteQuery("pr_employee");

            if (res > 0)
                Response.Write("Record Saved Success");
            else
                Response.Write("Record Not Saved");

            ShowGrid();
        }

        protected void txtclear_Click(object sender, EventArgs e)
        {
            txtempid.Text = "";
            txtempname.Text = "";
            gender.Text = "";
            txtcontact.Text = "";
            txtadhar.Text = "";
            txtaddress.Text = "";
            txtemail.Text = "";
            txtqua.Text = "";
            txtwork.Text = "";
            jobrole.Text = "";
            txtjoining.Text = "";
            txtempid.Focus();
        }

        protected void txtdelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ARE YOU SURE!!");
            DAL d = new DAL();
            d.ClearParameters();
            d.AddParameters("empid", Common.cint(txtempid.Text).ToString());
            d.isProcCall = true;
            d.AddParameters("action", "delete");
            int res = d.ExecuteQuery("pr_employee");

            if(res > 0)
            {
                Response.Write("Record delete success");
                txtempname.Text = "";
                gender.SelectedIndex = 0;
                txtcontact.Text = "";
                txtadhar.Text = "";
                txtaddress.Text = "";
                txtemail.Text = "";
                txtqua.Text = "";
                txtwork.Text = "";
                jobrole.Text = "";
                txtjoining.Text = "";

            }
            ShowGrid();
        }

        protected void txtempid_TextChanged(object sender, EventArgs e)
        {
            DAL d = new DAL();
            SqlDataReader rdr = d.GetDataReader("Select * from employee where empid =" + Common.cint(txtempid.Text));

            if (rdr != null && rdr.HasRows)
            {
                ViewState["foundflag"] = true;
                rdr.Read();
                txtempname.Text = rdr["empname"].ToString();
                gender.Text = rdr["gender"].ToString();
                txtcontact.Text = rdr["contact"].ToString();
                txtemail.Text = rdr["email"].ToString();
                txtadhar.Text = rdr["adhar"].ToString();
                txtaddress.Text = rdr["address"].ToString();
                txtwork.Text = rdr["workshift"].ToString();
                txtjoining.Text = rdr["joining_date"].ToString();
                jobrole.Text = rdr["job_role"].ToString();
                txtqua.Text = rdr["qualification"].ToString();

                rdr.Close();
            }
            else
            {
                ViewState["founddlag"] = false;
                txtempid.Text = "";
                txtempname.Text = "";
                gender.SelectedValue = "0";
                txtcontact.Text = "";
                txtadhar.Text = "";
                txtaddress.Text = "";
                txtemail.Text = "";
                txtqua.Text = "";
                txtwork.Text = "";
                jobrole.Text = "";
                txtjoining.Text = "";

            }
            txtempname.Focus();
        }

        protected void txtback_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }
    }
}