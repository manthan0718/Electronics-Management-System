﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Electronic_Management_System
{
    public partial class Add_Products : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                ViewState["foundflag"] = false;
                GetMaxID();
                ShowGrid();
            }
        }

        protected void ShowGrid()
        {
            DAL d = new DAL();
            DataTable dt = d.GetTable("Select * from Addproduct");
            grddata.DataSource = dt;
            grddata.DataBind();
        }

        public void GetMaxID()
        {
            try
            {
                DAL d = new DAL();
                d.isProcCall = true;
                d.ClearParameters();
                d.AddParameters("action", "getmax");
                d.AddParameters("pid", "0");
                object MaxId = d.GetID("pr_AddProduct");
                d.isProcCall = false;
                txtpid.Text = MaxId + "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        protected void txtsave_Click(object sender, EventArgs e)
        {
            DAL d = new DAL();
            d.ClearParameters();
            d.AddParameters("pid", txtpid.Text);
            d.AddParameters("ptype", txtptype.Text);
            d.AddParameters("pbrand", txtpbrand.Text);
            d.AddParameters("pname", txtname.Text);
            d.AddParameters("srno", txtserial.Text);
            d.AddParameters("warrenty", txtwarrenty.Text);
            d.AddParameters("gurantee", txtgurrenty.Text);
            d.AddParameters("supplier", txtsuppier.Text);
            d.AddParameters("contact", txtcontact.Text);
            d.AddParameters("importDate", txtimport.Text);
            d.isProcCall=true;

            if ((bool)ViewState["foundflag"])
            {
                d.AddParameters("action", "update");
            }
            else
            {
                d.AddParameters("action", "insert");
            }

            int res = d.ExecuteQuery("pr_AddProduct");

            if (res > 0)
                Response.Write("Record Saved Success");
            else
                Response.Write("Record Not Saved");
            ShowGrid();
        }

        protected void txtclear_Click(object sender, EventArgs e)
        {
            txtpid.Text = "";
            txtptype.Text = "";
            txtpbrand.Text = "";
            txtname.Text = "";
            txtserial.Text = "";
            txtwarrenty.Text = "";
            txtgurrenty.Text = "";
            txtsuppier.Text = "";
            txtcontact.Text = "";
            txtimport.Text = "";
            txtpid.Focus();
        }

        protected void txtdelete_Click(object sender, EventArgs e)
        {
            DAL d = new DAL();
            d.ClearParameters();
            d.AddParameters("pid", Common.cint(txtpid.Text).ToString());
            d.isProcCall = true;
            d.AddParameters("action", "delete");
            int res = d.ExecuteQuery("pr_AddProduct");

            if (res > 0)
            {
                Response.Write("Record delete success");
                txtpid.Text = "";
                txtptype.SelectedIndex = 0;
                txtpbrand.SelectedIndex = 0;
                txtname.Text = "";
                txtserial.Text = "";
                txtwarrenty.Text = "";
                txtgurrenty.Text = "";
                txtsuppier.Text = "";
                txtcontact.Text = "";
                txtimport.Text = "";
                txtpid.Focus();
            }
            ShowGrid();
        }

        protected void txthome_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }
    }
}