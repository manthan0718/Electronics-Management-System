﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Electronic_Management_System
{
    public partial class Sale_Product : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ViewState.Add("foundflag", false);
                GetMaxID();
                //ShowGrid();
            }

        }

        public void GetMaxID()
        {
            try
            {
                DAL d = new DAL();
                d.isProcCall = true;
                d.ClearParameters();
                d.AddParameters("action", "getmax");
                d.AddParameters("pid", "0");
                object MaxId = d.GetID("Sell_Products");
                d.isProcCall = false;
                txtpid.Text = MaxId + "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            DAL d = new DAL();
            d.ClearParameters();
            d.AddParameters("pid", txtpid.Text);
            d.AddParameters("ptype", txtptype.Text);
            d.AddParameters("pbrand", txtpbrand.Text);
            d.AddParameters("pname", txtpname.Text);
            d.AddParameters("srno", txtserial.Text);
            d.AddParameters("warrenty", txtwarrenty.Text);
            d.AddParameters("guarantee", txtgurrenty.Text);
            d.AddParameters("cname", txtcname.Text);
            d.AddParameters("cnumber", txtmono.Text);
            d.AddParameters("email", txtemail.Text);
            d.AddParameters("city", txtcity.Text);
            d.AddParameters("address", txtdelevery.Text);
            d.AddParameters("tamt", txttotal.Text);
            d.AddParameters("total", txtamount.Text);
            d.AddParameters("cgst",txtcgst.Text);
            d.AddParameters("sgst",txtsgst.Text);
            d.isProcCall = true;

            if ((bool)ViewState["foundflag"])
            {
                d.AddParameters("action", "update");
            }
            else
            {
                d.AddParameters("action", "insert");
            }

            int res = d.ExecuteQuery("Sell_Products");

            if (res > 0)
                Response.Write("Record Saved Success");
            else
                Response.Write("Record Not Saved");
        }

        protected void btnclear_Click(object sender, EventArgs e)
        {
            txtpid.Text = "";
            txtptype.Text = "";
            txtpbrand.Text = "";
            txtpname.Text = "";
            txtserial.Text = "";
            txtwarrenty.Text = "";
            txtgurrenty.Text = "";
            txtcname.Text = "";
            txtmono.Text = "";
            txtemail.Text = "";
            txtcity.Text = "";
            txtdelevery.Text = "";
            txttotal.Text = "";
            txtamount.Text = "";
            txtcgst.Text = "";
            txtsgst.Text = "";

            txtpid.Focus();
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            DAL d = new DAL();
            d.ClearParameters();
            d.AddParameters("pid", Common.cint(txtpid.Text).ToString());
            d.isProcCall = true;
            d.AddParameters("action", "delete");
            int res = d.ExecuteQuery("Sell_Products");

            if (res > 0)
            {
                Response.Write("Record delete success");

                txtpid.Text = "";
                txtptype.Text = "";
                txtpbrand.Text = "";
                txtpname.Text = "";
                txtserial.Text = "";
                txtwarrenty.Text = "";
                txtgurrenty.Text = "";
                txtcname.Text = "";
                txtmono.Text = "";
                txtemail.Text = "";
                txtcity.Text = "";
                txtdelevery.Text = "";
                txttotal.Text = "";
                txtamount.Text = "";
                txtcgst.Text = "";
                txtsgst.Text = "";
            }
        }

        protected void btnhome_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }
    }
}