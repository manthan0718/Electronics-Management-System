﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Electronic_Management_System
{
    public class Common
    {
        public static int cint(string input)
        {
            int x = 0;
            int.TryParse(input, out x);
            return x;
        }
        public static double cdouble(string input)
        {
            double x = 0;
            double.TryParse(input, out x);
            return x;
        }
        public static float cfloat(string input)
        {
            float x = 0;
            float.TryParse(input, out x);
            return x;
        }
        public static DateTime cdate(string input)
        {
            DateTime x;
            DateTime.TryParse(input, out x);
            return x;

        }

    }
}