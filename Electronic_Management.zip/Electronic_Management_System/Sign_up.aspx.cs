﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Electronic_Management_System
{
    public partial class Sign_up : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string username = txtuser.Text;
                string password = txtpass.Text;
                string action = "insert";

                DAL d = new DAL();

                d.isProcCall = true;
                d.ClearParameters();
                d.AddParameters("@username", username);
                d.AddParameters("@password", password);
                d.AddParameters("@action", action);

                int rowsAffected = d.ExecuteQuery("loginuser");

                if (rowsAffected > 0)
                {
                    Response.Write("Record Saved Successful!!!");
                }
                else
                {
                    Response.Write("Record Not Saved!!!");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login_Page.aspx");
        }
    }
}