﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Electronic_Management_System
{
    public partial class Login_Page : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                Session.Clear();
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            DAL d = new DAL();
            d.ClearParameters();
            d.isProcCall = false;
            SqlDataReader rdr = d.GetDataReader("Select * from users Where Username='" + txtuser.Text + "'");

            if (rdr != null && rdr.HasRows)
            {
                rdr.Read();
                if (txtpass.Text == rdr["password"].ToString())
                {
                    rdr.Close();
                    Response.Redirect("HomePage.aspx");
                }
                else
                {
                    Response.Write("Invalid Password!!");
                    txtpass.Focus();
                }
            }
            else
            {
                Response.Write("Invalid User!!");
                txtuser.Focus();
            }
            if (!rdr.IsClosed)
                rdr.Close();
        }

        protected void btnsign_Click(object sender, EventArgs e)
        {
            Response.Redirect("Sign_up.aspx");
        }
    }
}